# GithubStreaks
A Gnome Extension to see your GitHub commit history in top panel.
